#9C7655 드론
from djitellopy import Tello
import numpy as np
import cv2
import time
import threading
import queue 

# 드론 초기화
tello = Tello()
running = True

moving_event = threading.Event()  # 착륙 단계로 넘어가기 트리거
moving_queue = queue.Queue(maxsize=1)
latest_valid_mask_data = None

landing_event = threading.Event()  # 착륙 이벤트 설정
landing_queue = queue.Queue(maxsize=1)  # 착륙 좌표 전달용 큐

line_queue = queue.Queue(maxsize=1)  # 중앙 정렬 용 큐

def calibrate_imu(tello, samples=40):
    print("IMU 캘리브레이션 중...")
    pitch_sum = roll_sum = yaw_sum = 0

    for _ in range(samples):
        attitude = tello.query_attitude()  # ✅ 수정됨
        print(f"📡 {attitude}")
        pitch_sum += attitude['pitch']
        roll_sum += attitude['roll']
        yaw_sum += attitude['yaw']
        time.sleep(0.05)

    pitch_avg = pitch_sum / samples
    roll_avg = roll_sum / samples
    yaw_avg = yaw_sum / samples

    print("✅ 캘리브레이션 완료!")
    print(f"Offsets: pitch={pitch_avg:.2f}, roll={roll_avg:.2f}, yaw={yaw_avg:.2f}")


def detect_white_object(frame):
    """하얀색 객체 검출 후 영역 크기와 마스크 반환"""
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    # 기존보다 범위를 넓게 설정
    lower_white = np.array([0, 0, 160])     # V 값을 200 → 160으로 낮춤
    upper_white = np.array([180, 70, 255])  # S 값을 50 → 70으로 확장

    mask = cv2.inRange(hsv, lower_white, upper_white)
    mask = cv2.medianBlur(mask, 5)  # 노이즈 제거 (필요시 조정 가능)
    mask = cv2.GaussianBlur(mask, (5, 5), 0)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    if contours:
        largest_contour = max(contours, key=cv2.contourArea)
        area = cv2.contourArea(largest_contour)
        if area > 1000:
            return mask, area
    return None, 0

def process_landing_position(frame, mask, area):
    global moving_queue, latest_valid_mask_data

    height, width = frame.shape[:2]

    if mask is None:
        # 마스크가 없으면 직전 유효 데이터를 넣기
        if latest_valid_mask_data is not None:
            if moving_queue.full():
                moving_queue.get_nowait()
            moving_queue.put(latest_valid_mask_data)
        return

    # 마스크 처리
    left_white = np.sum(mask[:, :width // 2] == 255)
    right_white = np.sum(mask[:, width // 2:] == 255)
    top_white = np.sum(mask[:height // 2, :] == 255)
    bottom_white = np.sum(mask[height // 2:, :] == 255)
    white_area_ratio = np.sum(mask) / (frame.shape[0] * frame.shape[1])

    # 큐 갱신
    mask_data = (left_white, right_white, top_white, bottom_white, white_area_ratio)
    latest_valid_mask_data = mask_data  # 업데이트

    if moving_queue.full():
        moving_queue.get_nowait()
    moving_queue.put(mask_data)
    
    # 디버깅용 출력
    #print(f"Queue pushed: {left_white}, {right_white}, {top_white}, {bottom_white}, {white_area_ratio}")


# 원 검출 함수 (더 정밀하게 개선)
def detect_circular_object(frame):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    # 기존보다 범위를 넓게 설정
    lower_white = np.array([0, 0, 160])     # V 값을 200 → 160으로 낮춤
    upper_white = np.array([180, 70, 255])  # S 값을 50 → 70으로 확장

    mask = cv2.inRange(hsv, lower_white, upper_white)
    
    # 노이즈 제거 (Median Blur 적용)
    mask = cv2.medianBlur(mask, 5)
    
    # 원 검출을 위한 이미지 변환
    gray = cv2.bitwise_and(frame, frame, mask=mask)
    gray = cv2.cvtColor(gray, cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (9, 9), 2)
    
    # 적응형 임계값 적용 (더 선명한 윤곽 검출)
    gray = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
    
    # 원 검출 파라미터 조정중
    circles = cv2.HoughCircles(
    gray,                     # 입력 영상 (grayscale) – 원 검출 대상
    cv2.HOUGH_GRADIENT,       # 검출 방법: Hough Gradient 방식 사용
    dp=1.2,                   # 누적기 해상도 비율 (1이면 입력 이미지와 동일 해상도, >1이면 축소)
    minDist=50,               # 검출된 원 중심점 간의 최소 거리 (작게 하면 가까운 원도 구분 가능)
    param1=50,                # 내부 Canny edge 검출기의 upper threshold (lower는 param1의 절반으로 자동 설정됨)
    param2=40,                # 원으로 인정되기 위한 최소 누적 투표 수 (작게 할수록 민감해짐, 하지만 오탐 증가)
    minRadius=30,              # 검출할 원의 최소 반지름 (너무 크면 작은 원은 무시됨)
    maxRadius=80             # 검출할 원의 최대 반지름 (너무 작으면 큰 원 무시됨)
)

    # 큐가 꽉 차 있으면 기존 값 제거 후 최신 값 넣기
    if landing_queue.full():
        landing_queue.get_nowait()  # 가장 오래된 값 삭제

    if circles is not None:
        circles = np.uint16(np.around(circles))
        landing_queue.put(circles[0][0])  # 유효한 좌표만 저장
        moving_event.set() #착륙 단계로 넘어가기
        return circles[0][0]  # (x, y, r) 값 반환
    return None

def detect_black_line_and_enqueue(frame, line_queue):
    # 이미지를 흑백으로 변환
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # 이진화: 검은 선 강조
    _, binary = cv2.threshold(gray, 50, 255, cv2.THRESH_BINARY_INV)

    # 윤곽선 검출
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if contours:
        # 가장 큰 윤곽선 선택
        largest = max(contours, key=cv2.contourArea)
        M = cv2.moments(largest)
        if M['m00'] != 0:
            cx = int(M['m10'] / M['m00'])  # 중심 x좌표
            # 큐가 꽉 차 있으면 기존 값 제거 후 최신 값 넣기
            if line_queue.full():
                line_queue.get_nowait()  # 가장 오래된 값 삭제
            line_queue.put(cx)
            # print(f"검은 선 중심 x좌표: {cx} 저장 완료")

def align_drone_to_line(tello, line_queue, frame_width=640, tolerance=55):
    if line_queue.empty():
        print("⚠️ line 큐에 좌표 없음. 대기 중...")
        return
    
    x = line_queue.get()
    center_x = frame_width // 2
    error = x - center_x

    print(f"드론 중앙 정렬 중... 검은 선 x={x}, 중앙 기준={center_x}, 오차={error}")

    while abs(error) > tolerance:
        x = line_queue.get()
        center_x = frame_width // 2
        error = x - center_x

        if error > 0:
            print("➡️ 오른쪽으로 이동")
            tello.send_rc_control(15, 0, 0, 0)
            time.sleep(0.2)
            
        else:
            print("⬅️ 왼쪽으로 이동")
            tello.send_rc_control(-15, 0, 0, 0)
            time.sleep(0.2)
        
        tello.send_rc_control(0, 0, 0, 0)
        time.sleep(0.2)    
    
    print("✅ 중앙 정렬 완료")
    tello.send_rc_control(0, 0, 0, 0)
    time.sleep(0.2)

# 이동 함수
def smooth_takeoff():
    tello.takeoff()
    # 드론 안정화 시간을 충분히 주기 위한 대기
    print("🛫 이륙 후 안정화 대기 중...")   
    time.sleep(2)                  
    tello.send_rc_control(0, 0, 0, 0)
    time.sleep(2)                  
    print("🛫 이륙 준비 완료!")

def smooth_landing():
    tello.send_rc_control(0, 0, 0, 0)
    time.sleep(1)

    #현재 고도 가져오기
    altitude = tello.get_distance_tof()

    print("Landing...")
    tello.land()
    time.sleep(4)
    tello.end() 
    time.sleep(2)  # 포트 해제 후 2초 대기

def move_forward(y_speed, duration):
    for i in range (0,int(duration),1):
        tello.send_rc_control(0, y_speed, 0, 0)
        time.sleep(1)
        tello.send_rc_control(0, 0, 0, 0)
        time.sleep(1)

def brake():
    tello.send_rc_control(-5, 0, 0, 0)
    time.sleep(0.2)
    tello.send_rc_control(0, 0, 0, 0)
    time.sleep(0.2)

def get_speed_correction():
    battery = tello.get_battery()
    print(f"Battery: {battery}%")

    correction = 1.0
    if battery > 80:
        correction = 1.04
    elif battery < 50:
        correction = 0.97
    else:
        correction = 1.0
    return correction if correction > 0 else -correction

# 고도 유지 함수
def maintain_altitude(target_altitude):
    """드론의 고도를 목표 고도(target_altitude)로 유지"""
    current_altitude = tello.get_distance_tof()

    while abs(current_altitude - target_altitude) > 5:  # 목표 고도와의 차이가 5cm 이내가 될 때까지
        if current_altitude < target_altitude:
            tello.send_rc_control(0, 0, 18, 0)  # 목표 고도보다 낮으면 상승
        else:
            tello.send_rc_control(0, 0, -23, 0)  # 목표 고도보다 높으면 하강
        time.sleep(1)
        current_altitude = tello.get_distance_tof()
        print(f"Current altitude: {current_altitude}cm, Target altitude: {target_altitude}cm")

    tello.send_rc_control(0, 0, 0, 0)  # 고도 유지 후 제어 멈추기
    print(f"Altitude maintained at: {current_altitude}cm")
    time.sleep(3)

# 영상 스트리밍 및 감지 데이터 큐에 저장
def stream_video():
    global running
    tello.streamon()
    time.sleep(2)
    
    while running:
        frame = tello.get_frame_read().frame
        if frame is None or frame.size == 0:
            print("Error: Empty frame received from the drone camera")
            continue
        
        frame = cv2.resize(frame, (640, 480))

        # 이미지 처리
        circle = detect_circular_object(frame)
        if circle is not None and circle.any():
            x, y, r = circle
            cv2.circle(frame, (x, y), r, (0, 255, 0), 4)  # 원 그리기
            cv2.circle(frame, (x, y), 5, (0, 0, 255), -1)  # 원의 중심에 점 찍기

        cv2.imshow("Drone View", frame)

        mask, area = detect_white_object(frame)
        
        # 마스크 처리
        if mask is not None:
            process_landing_position(frame, mask, area)
            cv2.imshow("Mask", mask)  # mask가 존재할 때만 표시

        key = cv2.waitKey(5) & 0xFF # -> 추가된 코드

        detect_black_line_and_enqueue(frame, line_queue)

        if key == ord('e'):
            print("🛑 Emergency landing triggered by user (key: e)") # 강제 착륙
            running = False
            moving_event.set()
            landing_event.set()
            tello.send_rc_control(0, 0, 0, 0)  # 즉시 제어 중단
            tello.land()
            time.sleep(3)
            tello.end()
            break
 
    tello.streamoff()
    cv2.destroyAllWindows()    

 # 드론 이동 및 착륙
def drone_movement():
    global moving_queue

    # 센서 초기화
    print(f"초기 고도: {tello.get_height()} cm")  
    time.sleep(1)

    smooth_takeoff()
    maintain_altitude(100)  # 목표 고도 100 유지(이거 수정하면 안됨)
    time.sleep(1.5)


    # A 장애물 통과 하기 전
    maintain_altitude(145)  # 목표 고도 145 (이건 수정 가능)
    speed_factor = get_speed_correction()
    move_forward(int(44*speed_factor), 1)
    tello.send_rc_control(0, 10, 0, 0)  # 좌측으로 살짝 이동 # 직진시 고도가 떨어짐, 살짝 왼쪽으로 이동하는 경향 있음 
    align_drone_to_line(tello, line_queue)

    # A 장애물 통과
    speed_factor = get_speed_correction()
    move_forward(int(39*speed_factor), 1)
    tello.send_rc_control(0, 10, 0, 0)  # 좌측으로 살짝 이동
    
    # B 장애물 통과
    maintain_altitude(95)  # 목표 고도 95 유지
    align_drone_to_line(tello, line_queue)
    speed_factor = get_speed_correction()
    move_forward(int(39*speed_factor), 1)
    

    # B 장애물 통과 후 회전
    tello.rotate_clockwise(90)  # 90도 우회전
    time.sleep(1)
    move_forward(int(43*speed_factor), 1)
    tello.send_rc_control(-7, 0, 0, 0)  # 왼쪽 이동
    time.sleep(0.5)
    
    # C 장애물 통과 전
    speed_factor = get_speed_correction()
    move_forward(int(43*speed_factor), 1) # 일단 직진한다음에 
    maintain_altitude(145)  # 150
    tello.send_rc_control(0, 10, 0, 0)  # 좌측으로 살짝 이동
    align_drone_to_line(tello, line_queue)

    speed_factor = get_speed_correction()

    # C 장애물 통과
    speed_factor = get_speed_correction()
    move_forward(int(46*speed_factor), 2)
    align_drone_to_line(tello, line_queue)


    print("moving_event 상태:", moving_event.is_set())
    print("landing_event 상태:", landing_event.is_set())

    # 착륙 단계
    while not landing_event.is_set(): 
        while not moving_event.is_set():
            try:
                # 최신 데이터를 가져오기
                latest_data = moving_queue.get(timeout=1)
                
                left, right, top, bottom, ratio = latest_data
                print(f"Processed Data: Left={left}, Right={right}, Top={top}, Bottom={bottom}, Ratio={ratio:.2f}")
                
                # 이동 로직
                if bottom < top:
                    tello.send_rc_control(0, 15, 0, 0)  # 앞로 이동
                    time.sleep(0.8)
                elif top < bottom:
                    tello.send_rc_control(0, -16, 0, 0)  # 뒤로 이동
                    time.sleep(0.8)
                elif left < right:
                    tello.send_rc_control(7, 0, 0, 0)  # 오른쪽 이동
                    time.sleep(0.8)
                elif right < left:
                    tello.send_rc_control(-8, 0, 0, 0)  # 왼쪽 이동
                    time.sleep(0.8)
                

                tello.send_rc_control(0, 0, 0, 0)
                time.sleep(1.8)

                maintain_altitude(120)  # 목표 고도 120 유지

            except queue.Empty:
                continue

        while not landing_event.is_set():
            try:
                latest_data_c = landing_queue.get(timeout=1)
                circle = latest_data_c   # 착륙 큐에서 데이터 가져오기
                # print(f"Raw Circle Data from Queue: {circle}")  # 디버깅 코드 3

                if circle is not None and isinstance(circle, np.ndarray) and circle.size > 0:
                    x, y, r = np.round(circle).astype(int)  # 반올림 후 정수 변환
                    print(f"x, y, r: {x} / {y} / {r}")  # 디버깅 코드 4

                    if y < 190:
                        tello.send_rc_control(0, 15, 0, 0)  # 전진
                        time.sleep(0.8)
                    elif y > 230:
                        tello.send_rc_control(0, -16, 0, 0)  # 후진
                        time.sleep(0.8)

                    elif x < 310:
                        tello.send_rc_control(-12, 0, 0, 0)  # 좌측 이동
                        time.sleep(0.8)
                    elif x > 345:
                        tello.send_rc_control(7, 0, 0, 0)  # 우측 이동 할 때 조금씩 앞으로 나와서 보정
                        time.sleep(0.8)

                    tello.send_rc_control(0, 0, 0, 0)   
                    time.sleep(2)

                    if 310 < x < 345 and 190 < y < 230:
                        print(f"land x, y, r: {x} / {y} / {r}")
                        landing_event.set()  # 착륙 이벤트 트리거

            except queue.Empty:
                moving_event.clear() # 원 찾기로 돌아가기
                print("Queue is empty! No circle data received.")  # 디버깅 코드 5 
                break   

    smooth_landing()
    

if __name__ == "__main__": #추가됨
    tello.connect()
    time.sleep(1)

    battery = tello.get_battery()
    if battery is None:
        battery = 50
    print(f"Battery: {battery}%")
    time.sleep(1)

    calibrate_imu(tello)

    # 스레드 실행 (tello 초기화 후 실행해야 에러 없음)
    video_thread = threading.Thread(target=stream_video)
    movement_thread = threading.Thread(target=drone_movement)

    video_thread.start()
    movement_thread.start()

    video_thread.join()
    movement_thread.join()